1. Ensure Seq2Geno2Pheno is installed, which includes the required environment variables (please refer to the main README.md)
2. Move this folder `sgp_example` to any suitable folder and run the commands:

```
## step 1. create the input file and commands
./CONFIG.sh
## We recommend to review the options.sgp.yml and toy.sh before the next step starts
## step 2. run the command
bash ./toy.sh
```

3. Compare the results to our precomputed one. They are ideally the same or at least very similar.
