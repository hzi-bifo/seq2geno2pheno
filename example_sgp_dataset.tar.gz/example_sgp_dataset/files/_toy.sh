#!/bin/bash
#$ -V
#$ -l h_core=15
#$ -l h_vmem=300G

cd __
source activate sgp_env
sgp -f options.sgp.yaml
