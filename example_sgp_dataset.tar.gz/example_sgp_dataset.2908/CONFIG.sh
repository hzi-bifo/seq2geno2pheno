#!/bin/bash

cat files/_options.sgp.yaml | sed "s#^\(\s\+\)\/#\1$(realpath ./)\/#g" \
  > options.sgp.yaml

cat files/_toy.sh | sed "s#__#$(realpath ./)\/#g" \
  > toy.sh
chmod +x toy.sh

cat files/_dna_list | sed "s#__#$(realpath ./)\/#g" \
  > dna_list

cat files/_rna_list | sed "s#__#$(realpath ./)\/#g" \
  > rna_list
