1. Ensure Seq2Geno2Pheno is installed, which includes the required environment variables (please refer to the main README.md)
2. Move this folder `sgp_example` to any suitable folder and run the commands:

```
## step 1. create the input file and commands
## The computational resources or paths stated in these created files may need changes,
## so we recommend to review the files prior to the enxt step
./CONFIG.sh

## step 2. run the command
./toy.sh
```
3. Compare the results to our precomputed ones. They should look ideally the same or very similar.
